#
# phpBB Backup Script
# Dump of tables for phpbb_
# DATE : 12-04-2020 16:26:54 GMT
#
# Table: phpbb_ad_locations
DROP TABLE IF EXISTS phpbb_ad_locations;
CREATE TABLE `phpbb_ad_locations` (
  `ad_id` mediumint(8) unsigned NOT NULL DEFAULT 0,
  `location_id` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  PRIMARY KEY (`ad_id`,`location_id`),
  KEY `location_id` (`location_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

